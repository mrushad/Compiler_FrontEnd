//ERROR FREE: This testcase contains a program that evaluates expressions
#include<stdio.h>
void main()
{
	int a = 0;
	int b = 2;
	int c = 5;
	int d = 10;
	int result;
	result = a + b*(c + d);
}
