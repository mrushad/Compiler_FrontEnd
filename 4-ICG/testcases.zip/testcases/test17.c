//WITH ERROR - This test case includes a function call to undeclared function
#include<stdio.h>
void main()
{
	func();
}
