//WITH ERROR - This test case includes case where lhs of assignment has more than 1 single variable
#include<stdio.h>
void main()
{
	int x = 1;
	int y = 1;
	int z = 1;
	x + y = z;

}

