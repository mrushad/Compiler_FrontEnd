//WITH ERROR - This test case includes case where array identifier has no subscript
#include<stdio.h>
void main()
{
	int ar[2] = {1,2};
	ar = 3;
}

