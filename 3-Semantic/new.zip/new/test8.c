//ERROR FREE - This test case includes nested comments
#include<stdio.h>

int main()
{
	/*This is /* nested comment */!!*/
	/*This is a
	normal comment*/
}
	