//ERROR FREE - This test case includes declaration of a structure
#include<stdio.h>

struct book
{
	char name[10];
	char author[10];
};

int main()
{
	int num = 3;
	printf("Hello");

}
	