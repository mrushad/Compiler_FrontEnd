//ERROR FREE - This test includes a declaration and a print statement
#include<stdio.h>

int main()
{
	//This is the first test program.
	int a;
	/* This is the declaration
	of an integer value */
	
	printf("Hello World");
	return 0;
}