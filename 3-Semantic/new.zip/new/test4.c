//ERROR FREE - This test case includes for and while loops
#include<stdio.h>

int main()
{
	int num = 3;
	
	for(int i = 0; i < num; i++)
		printf("Hello");
	
	while(num > 0)
	{
		printf("Hello");
		num--;
	}
}
	
