//WITH ERROR - This test case includes void parameter for function
#include<stdio.h>
void func(void x)
{
	printf("hello\n");
}
void main()
{
	printf("hello\n");
}
