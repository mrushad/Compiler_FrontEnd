//WITH ERROR - This test case includes array size less than 1
#include<stdio.h>

void main()
{
	int a[0];
	printf("hello\n");
	
}
