//WITH ERROR - This test case includes call to undeclared function
#include<stdio.h>
void main()
{
	func();
}

