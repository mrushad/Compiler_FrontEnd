//WITH ERROR - This test case includes if condition not of type int
#include<stdio.h>
void main()
{
	float x = 1.0;
	if(x)
		print("hello\n");
}

