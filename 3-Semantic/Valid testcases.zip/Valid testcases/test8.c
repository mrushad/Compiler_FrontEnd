//ERROR FREE - This test case includes nested loops
#include<stdio.h>

int main()
{
	int num = 3;
	
	for(int i = 0; i<num; i++)
	{
		for(int j = 0; j < num; j++)
			printf("Hello");
	}
}
	