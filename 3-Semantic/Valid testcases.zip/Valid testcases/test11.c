//ERROR FREE - This test case includes escape sequences
#include<stdio.h>

int main()
{
	char es = '\a';
	printf("Hello");

}
	